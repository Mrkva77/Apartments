function benko(){
    alert("benko je legenda");
}